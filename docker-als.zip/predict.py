import os
import json
import pandas as pd
import pickle as pkl

# LOAD MODEL
model = pkl.load(open('model.sav', 'rb'))


def handler(event, context):
    # PREDICT
    prediction = model.similar_items(318, 11)
    return {
        'prediction': str(prediction)
    }
